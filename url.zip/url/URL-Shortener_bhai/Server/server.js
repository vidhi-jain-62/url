var express = require("express")
var cors = require("cors")
var bodyParser = require("body-parser")
var app = express()
require('dotenv').config()
var mongoose = require("mongoose")
var Users = require('./routes/Users')
var port = process.env.PORT || 3003

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
  });

app.use(bodyParser.json())
// app.use(cors())
const corsOptions = {
    origin: true,
    optionsSuccessStatus: 204,
    credentials: true,
  };
  
  // Cors Middleware
  app.use(cors(corsOptions));

  
app.use(
    bodyParser.urlencoded({
        extended: false
    })
)

const mongoURI = 'mongodb+srv://root:1234567890@cluster0.ixdnz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

mongoose
    .connect(mongoURI, {useNewUrlParser: true})
    .then(() => console.log("MongoDB Connected"))
    .catch(err => console.log("MongoDB Connection Error: "+err))

app.use('/users', Users)

app.listen(port, () => {
    console.log("Server is Running on Port: " + port)
})