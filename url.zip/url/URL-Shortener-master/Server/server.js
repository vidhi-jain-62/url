var express = require("express")
var cors = require("cors")
var bodyParser = require("body-parser")
var path= require("path")
var app = express()
require('dotenv').config()
var mongoose = require("mongoose")
var Users = require('./routes/Users')
var port = process.env.PORT || 3003
if (process.env.NODE_ENV == 'production') {

app.use("/",express.static("Client/build"));

app.use(bodyParser.json())
app.use(cors())   
app.use(
    bodyParser.urlencoded({ 
        extended: false
    })
)

const mongoURI = 'mongodb+srv://root:1234567890@cluster0.ixdnz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'

mongoose
    .connect(mongoURI, {useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("MongoDB Connected"))
    .catch(err => console.log("MongoDB Connection Error: "+err))
 
app.use('/users', Users)   

app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'Client', 'build', 'index.html'));
  });
}  

app.listen(port, () => {
    console.log("Server is Running on Port: " + port)
})  